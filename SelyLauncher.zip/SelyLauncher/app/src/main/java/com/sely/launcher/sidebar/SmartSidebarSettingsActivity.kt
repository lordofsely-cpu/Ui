package com.sely.launcher.sidebar

import android.os.Bundle
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.sely.launcher.databinding.ActivitySmartSidebarSettingsBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Smart Sidebar customization: edge (left/right), panel width, and
 * transparency — the spec's "customizable position, size, transparency,
 * width" (theme/dark-light is just ThemeManager, already shared by
 * every Sely screen, so there's nothing sidebar-specific to add there).
 *
 * Values are read fresh by SmartSidebarService each time its handle or
 * panel is (re)created, so there's no live-reload wiring needed here —
 * saving a SharedPreferences value is enough.
 */
class SmartSidebarSettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySmartSidebarSettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySmartSidebarSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backArrow.setOnClickListener { finish() }

        binding.edgeSwitch.isChecked = SmartSidebarPrefs.isRightEdge(this)
        binding.edgeSwitch.setOnCheckedChangeListener { _, checked ->
            SmartSidebarPrefs.setRightEdge(this, checked)
        }

        binding.widthSlider.progress = SmartSidebarPrefs.getPanelWidthDp(this) - 220
        binding.widthSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) SmartSidebarPrefs.setPanelWidthDp(this@SmartSidebarSettingsActivity, 220 + progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.transparencySlider.progress = SmartSidebarPrefs.getAlphaPercent(this) - 40
        binding.transparencySlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) SmartSidebarPrefs.setAlphaPercent(this@SmartSidebarSettingsActivity, 40 + progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
    }

    private fun applyTheme() {
        val textPrimary = ThemeManager.textPrimary(this)
        val textSecondary = ThemeManager.textSecondary(this)
        ThemeManager.applyIosBackground(binding.sidebarSettingsRoot)
        binding.screenTitle.setTextColor(textPrimary)
        binding.edgeLabel.setTextColor(textPrimary)
        binding.widthLabel.setTextColor(textPrimary)
        binding.transparencyLabel.setTextColor(textPrimary)
        binding.previewNote.setTextColor(textSecondary)
    }
}
